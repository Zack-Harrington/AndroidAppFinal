package com.androidatc.simonsays

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.game.*
import kotlinx.android.synthetic.main.game.view.*

class Game : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.game)

            val start = 0
            val end = 9
            var index = 1

            var answer = rand(start, end)

            do {
                var guess: Nothing? = theGuess.text as Nothing?
                if (guess == answer) {
                    results.text = "You win!"
                    break
                }
                else {results.text = "Wrong, try again"}
                }
                while (index < 4)
                if (index == 4) {
                    results.text = "Sorry, you lose"}
            }
    }



fun rand(start: Int, end: Int): Int {
    require(start <= end) { "Illegal Argument" }
    return (start..end).random()
}