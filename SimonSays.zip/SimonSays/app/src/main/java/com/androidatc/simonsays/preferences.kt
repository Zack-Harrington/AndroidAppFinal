package com.androidatc.simonsays

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.preferences.*

abstract class Preferences : AppCompatActivity() {

    companion object {
        private const val Day = R.style.Theme_SimonSays
        private const val Night = R.style.Theme_NightMode
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.preferences)

        DayModeBtn.setOnClickListener{
            switchTheme("Theme.SimonSays")
        }

        nightModeBtn.setOnClickListener{
            switchTheme("Theme.NightMode")
        }

    }

    private fun switchTheme(s: String) {

    }
}