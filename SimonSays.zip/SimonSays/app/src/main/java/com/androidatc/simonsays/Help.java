package com.androidatc.simonsays;

import android.app.Activity;

public class Help extends Activity {
}
